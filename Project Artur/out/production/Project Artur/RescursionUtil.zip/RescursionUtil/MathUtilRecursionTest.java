package RescursionUtil;

public class MathUtilRecursionTest {
    public static void main(String[] args) {
        MathUtilRecursion mathUtilRecursion=new MathUtilRecursion();
        System.out.println(mathUtilRecursion.raiseToPower(4,2));
        System.out.println(MathUtilRecursion.reverse(5784532));
    }
}

