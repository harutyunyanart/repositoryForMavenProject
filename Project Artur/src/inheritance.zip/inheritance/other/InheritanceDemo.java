package inheritance.other;

import inheritance.figure.Circle;
import inheritance.figure.Figure;
import inheritance.figure.Rectangle;
import inheritance.figure.Square;

public class InheritanceDemo {
    public static void main(String[] args) {
        Object o = new Object();
//        Figure figure = new Rectangle(12,45,78,96);
//        System.out.println(figure.getDiagonal());
//        Rectangle rectangle = new Rectangle(12,45,78,96);
//        figure = new Circle(40,40, 50);
//        figure = new Human();
//        System.out.println(figure.getArea());
//        System.out.println(rectangle.getArea());
//        System.out.println(figure.getDiagonal());
//        System.out.println(figure instanceof Figure);
//        System.out.println(figure instanceof Object);
//        System.out.println(figure instanceof Rectangle);
//        System.out.println(figure instanceof Circle);
//        Figure f1 = new Rectangle(10,10,10,10);
//        Figure f2 = new Square(10,10,10);
//        System.out.println(f2.equals(f1));
//        System.out.println(f1);
//        System.out.println(f2);
    }
}
