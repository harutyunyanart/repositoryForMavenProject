package inheritance.figure;

public class Square extends Rectangle{

    public Square(int x, int y, int width, FigureCanvas canvas){
        super(x, y, width, width, canvas);
//        super.x = 54;
    }

}
