package inheritance.figure;

import javax.swing.*;

public class Demo {

    public static int get5(){
        return 5;
    }
    public static void main(String[] args) {
        int number = get5();
        int n2 = number * 3;
        System.out.println(n2);
    }
}
